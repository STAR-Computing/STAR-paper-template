#!/usr/bin/env python3
"""Build STAR's S-and-spark identity as vector SVG/PDF and transparent PNG.

STAR stands for System Trustworthiness and AI Reliability.

Regeneration uses rsvg-convert and pdftocairo. The supporting lettering
uses Arial during regeneration; the A is a custom path. Final assets contain outlines,
so Overleaf and consumers do not need any fonts or external tools.
"""
from pathlib import Path
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
WORK = ROOT / "build" / "identity-refinement"
ASSETS.mkdir(exist_ok=True)
WORK.mkdir(parents=True, exist_ok=True)
MIDNIGHT, CYAN = "#25356B", "#00A8C6"
FULL_NAME = "System Trustworthiness and AI Reliability"


def emblem(primary, accent, small=False):
    """Balanced S strokes rotate around a centered star-shaped opening.

    The small-use drawing opens the narrow channels for 16-32 pixel icons.
    Both versions remain vector paths with real transparent negative space.
    """
    tip, reach = (49, 30) if small else (50, 31)
    curve = f'''M46 4 H96 C94 19 83 28 68 28 H33
      C34 34 40 36 {tip} 36 L48 44 Q47 48 43 49 L{reach} 52
      L43 55 Q47 56 48 60 L{tip} 68
      C45 63 39 62 30 62 H27 C11 62 3 54 3 42
      C3 25 28 4 46 4 Z'''
    return (f'<path fill="{primary}" d="{curve}"/>'
            f'<path fill="{accent}" transform="rotate(180 52 52)" d="{curve}"/>')


def lettering(primary, shift=0):
    # The A repeats the emblem's four-point aperture in its counter. Its outer
    # silhouette stays conventional so STAR remains easy to read at small size.
    custom_a = '''M0 55.5 L21 0 H34 L55 55.5 H42 L37.5 43
      H17.5 L13 55.5 Z
      M27.5 14 L30 22 Q31 24.3 33.5 25 L38 27
      L33.5 29 Q31 29.7 30 32 L27.5 38
      L25 32 Q24 29.7 21.5 29 L17 27 L21.5 25
      Q24 24.3 25 22 Z'''
    return f'''<g fill="{primary}" transform="translate(0 {shift})">
      <text x="124" y="78" font-family="Arial, sans-serif" font-size="76"
        font-weight="700" letter-spacing="-.6">ST</text>
      <path transform="translate(220.4 23.6) scale(1 .98)" fill-rule="evenodd" d="{custom_a}"/>
      <text x="278" y="78" font-family="Arial, sans-serif" font-size="76"
        font-weight="700">R</text>
      <text x="348" y="78" font-family="Arial, sans-serif" font-size="36"
        font-weight="400" letter-spacing="1.1">LAB</text>
    </g>'''


def document(contents, width, height, title, description):
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%s" height="%s" '
            'viewBox="0 0 %s %s" role="img" aria-labelledby="title desc">'
            '<title id="title">%s</title><desc id="desc">%s</desc>%s</svg>' %
            (width, height, width, height, title, description, contents))


def export(name, svg, width, outline=False):
    source = WORK / (name + "-source.svg")
    source.write_text(svg)
    pdf = ASSETS / (name + ".pdf")
    subprocess.run(["rsvg-convert", "-f", "pdf", "-o", str(pdf), str(source)], check=True)
    destination = ASSETS / (name + ".svg")
    if outline:
        # Cairo converts supporting lettering to reusable glyph paths.
        subprocess.run(["pdftocairo", "-svg", str(pdf), str(destination)], check=True)
        # Re-export the outlined SVG so the PDF also contains no font objects.
        subprocess.run(["rsvg-convert", "-f", "pdf", "-o", str(pdf),
                        str(destination)], check=True)
    else:
        destination.write_text(svg)
    subprocess.run(["rsvg-convert", "-w", str(width), "-o",
                    str(ASSETS / (name + ".png")), str(destination)], check=True)


for suffix, primary, accent in [("", MIDNIGHT, CYAN),
                                 ("-mono", "#202020", "#202020"),
                                 ("-reverse", "#FFFFFF", CYAN)]:
    mark = emblem(primary, accent)
    export("star-mark" + suffix,
           document(mark, 104, 104, "STAR Lab S monogram",
                    "Balanced S strokes surround a centered four-point star. " + FULL_NAME), 1040)
    export("star-mark-small" + suffix,
           document(emblem(primary, accent, small=True), 104, 104,
                    "STAR Lab small-use monogram", "Open-channel variant for small icons."), 1040)
    lockup = mark + lettering(primary)
    export("star-lockup" + suffix,
           document(lockup, 432, 104, "STAR Lab",
                    "S-and-star monogram and custom star-counter A. " + FULL_NAME),
           2240, outline=True)
    signature = (mark + lettering(primary, shift=-8) +
                 f'<text x="124" y="99" fill="{primary}" '
                 'font-family="Arial, sans-serif" font-size="14.5" '
                 f'font-weight="400">{FULL_NAME}</text>')
    export("star-signature" + suffix,
           document(signature, 432, 104, "STAR Lab - " + FULL_NAME,
                    "The full lab signature for larger uses."), 2240, outline=True)

# Native vector rendering for small application icons; no bitmap tracing.
for size in [16, 24, 32, 48, 64, 128, 256]:
    source = ASSETS / ("star-mark-small.svg" if size <= 32 else "star-mark.svg")
    subprocess.run(["rsvg-convert", "-w", str(size), "-h", str(size),
                    "-o", str(ASSETS / f"star-icon-{size}.png"), str(source)], check=True)
icon_sizes = [16, 32, 48]
icon_data = [(ASSETS / f"star-icon-{size}.png").read_bytes() for size in icon_sizes]
offset = 6 + 16 * len(icon_sizes)
entries = []
for size, payload in zip(icon_sizes, icon_data):
    entries.append(struct.pack("<BBBBHHII", size, size, 0, 0, 1, 32, len(payload), offset))
    offset += len(payload)
(ASSETS / "star-favicon.ico").write_bytes(
    struct.pack("<HHH", 0, 1, len(icon_sizes)) + b"".join(entries) + b"".join(icon_data))

# A presentation preview is intentionally on white; production PNGs remain
# transparent, including the reverse mark for dark backgrounds.
color = (ASSETS / "star-lockup.svg").read_text()
start = color.index(">", color.index("<svg")) + 1
color = color[:start] + '<rect width="100%" height="100%" fill="white"/>' + color[start:]
(WORK / "preview.svg").write_text(color)
(ROOT / "output").mkdir(exist_ok=True)
subprocess.run(["rsvg-convert", "-w", "1792", "-o",
                str(ROOT / "output" / "STAR-logo-preview.png"),
                str(WORK / "preview.svg")], check=True)

# A review sheet shows the actual identity at large, small, and one-ink sizes.
sheet = ('<rect width="1280" height="650" fill="white"/>'
         '<text x="72" y="48" font-family="Arial, sans-serif" font-size="12" '
         'letter-spacing="1.4" fill="#5C6577">STAR LAB / IDENTITY SYSTEM</text>'
         '<g transform="translate(72 90) scale(2.6)">' + emblem(MIDNIGHT, CYAN) +
         lettering(MIDNIGHT, shift=-8) +
         f'<text x="124" y="99" fill="{MIDNIGHT}" font-family="Arial, sans-serif" '
         f'font-size="14.5">{FULL_NAME}</text></g>'
         '<path d="M72 410 H1208" stroke="#D3DBE7"/>'
         '<text x="72" y="460" font-family="Arial, sans-serif" font-size="11" '
         'letter-spacing="1" fill="#5C6577">SMALL-SIZE MARK</text>'
         '<text x="440" y="460" font-family="Arial, sans-serif" font-size="11" '
         'letter-spacing="1" fill="#5C6577">ONE COLOR</text>')
for size, x in [(16, 72), (24, 136), (32, 208), (48, 288)]:
    sheet += (f'<g transform="translate({x} {532-size}) scale({size/104})">' +
              emblem(MIDNIGHT, CYAN, small=size<=32) + '</g>' +
              f'<text x="{x}" y="560" font-family="Arial, sans-serif" '
              f'font-size="12" fill="#5C6577">{size}px</text>')
sheet += ('<g transform="translate(440 486) scale(.72)">' + emblem("#202020", "#202020") +
          lettering("#202020") + '</g>'
          f'<rect x="848" y="438" width="360" height="148" rx="12" fill="{MIDNIGHT}"/>'
          '<text x="866" y="462" font-family="Arial, sans-serif" font-size="11" '
          'letter-spacing="1" fill="white">ON DARK</text>'
          '<g transform="translate(866 485) scale(.75)">' + emblem("#FFFFFF", CYAN) +
          lettering("#FFFFFF") + '</g>')
(WORK / "identity-preview.svg").write_text(document(
    sheet, 1280, 650, "STAR Lab identity", FULL_NAME))
subprocess.run(["rsvg-convert", "-o", str(ROOT / "output" / "STAR-identity-preview.png"),
                str(WORK / "identity-preview.svg")], check=True)
print("Built color, monochrome, and reverse S-and-star monograms and lockups.")
